@extends('layouts.master')

@section('content')
        <h1>{{ $title }}</h1>
        <p>This is the about page for an example Laravel web application.</p>
@endsection
    