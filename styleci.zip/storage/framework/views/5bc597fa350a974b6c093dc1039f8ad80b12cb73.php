

<?php $__env->startSection('content'); ?>
<div class="container w-50 p-3" style="margin-top: 10%;">
<form action="/upload" method="POST" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>

<?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <strong><?php echo e($message); ?></strong>
            </div>
          <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>

  <div class="form-group mb-4">
  <label for="sel1">Select list:</label>
  <select class="form-control" id="sel1">
    <option>1</option>
    <option>2</option>
    <option>3</option>
    <option>4</option>
  </select>
  </div>

  <div class="form-outline mb-4">
    <label class="form-label d-flex justify-content-start" for="form2Example1">File</label>
    <input type="file" name="file" id="form2Example1" class="form-control" />
  </div>

  <!-- Submit button -->
  <div class="d-flex justify-content-end">
    <input type="submit" class="btn btn-primary btn-block mb-4" name="upload" value="Upload" />
  </div>
</form>
</div>

<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\minenovel\resources\views/upload.blade.php ENDPATH**/ ?>