    

    <?php $__env->startSection('content'); ?>
            <div class="row">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">File</th>
                                <th scope="col">Title</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td>
                                    
                                    <?php if( in_array(pathinfo($item->file, PATHINFO_EXTENSION), ['png', 'jpg', 'JPEG'])): ?>
                                        <img src="<?php echo e(asset('file_upload')); ?>/<?php echo e($item->file); ?>" style="height: 60px">
                                    <?php else: ?>
                                        <img src="https://www.freeiconspng.com/uploads/file-txt-icon--icon-search-engine--iconfinder-14.png"
                                        style="height: 10%">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->title); ?></td>
                                <td>
                                <a href="<?php echo e(route('create', ['novelId' => $item->title])); ?>" class="btn btn-primary">Select</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            </div>

    <?php $__env->stopSection(); ?>
        
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\minenovel\resources\views/list-novel.blade.php ENDPATH**/ ?>