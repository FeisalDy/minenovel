

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-5">
                <div class="card">
                    <div class="card-body">
                        
                        <form action="<?php echo e(url('input/proses')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-outline mb-4">
                            <label class="form-label d-flex justify-content-start" for="form2Example1">Image</label>
                            <input type="file" name="file" id="form2Example1" class="form-control" />
                            </div>
                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-outline mb-4">
                            <label class="form-label d-flex justify-content-start" for="form2Example1">Title</label>
                            <input type="text" name="title" placeholder="Title"id="form2Example1" class="form-control" />
                            </div>
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-outline mb-4">
                            <label class="form-label d-flex justify-content-start" for="form2Example2">Keterangan</label>
                            <textarea class="form-control" name="keterangan" id="form2Example2" rows="10"></textarea>
                            </div>
                            <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="d-flex justify-content-end">
                            <input type="submit" class="btn btn-primary btn-block mb-4" name="upload" value="Upload" />
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-7">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">File</th>
                            <th scope="col">Title</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->firstItem()+$key); ?></td>
                            <td>
                                
                                <?php if( in_array(pathinfo($item->file, PATHINFO_EXTENSION), ['png', 'jpg', 'JPEG'])): ?>
                                    <img src="<?php echo e(asset('file_upload')); ?>/<?php echo e($item->file); ?>" style="height: 60px">
                                <?php else: ?>
                                    <img src="https://www.freeiconspng.com/uploads/file-txt-icon--icon-search-engine--iconfinder-14.png"
                                    style="height: 60px">
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->title); ?></td>
                            <td>
                            <a href="<?php echo e(route('inputchapter', ['novelId' => $item->title])); ?>" class="btn btn-primary">Select</a>
                            <a href="<?php echo e(route('deletenovel', ['novelId' => $item->title])); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?')" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-center">
                <?php echo $data->links(); ?>

                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\minenovel\resources\views/input.blade.php ENDPATH**/ ?>