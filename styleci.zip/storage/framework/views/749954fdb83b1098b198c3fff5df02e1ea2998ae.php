

<?php $__env->startSection('content'); ?>
<div class="row">
            <div class="col-5">
                <div class="card">
                    <div class="card-body">
                        
                        <form action="<?php echo e(url('input/chapter/proses')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h3><?php echo e($data2->title); ?></h3>

                            <?php 
                            $title = $data2->title;
                            ?>
                            <input type="hidden" name="title" value="<?php echo $title?>">

                            <br>
                            <div class="form-outline mb-4">
                            <input type="file" name="text" id="form2Example1" class="form-control" />
                            </div>
                            <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="d-flex justify-content-end">
                            <input type="submit" class="btn btn-primary btn-block mb-4" name="upload" value="Upload" />
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-7">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Judul</th>
                            <th scope="col">Chapter</th>
                            <th scope="col">
                            <a href="<?php echo e(route('deletechapter', ['novelId' => $data3])); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?')" class="btn btn-danger">Delete</a>

                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($item->title); ?>

                            </td>
                            <td>Chapter <?php echo e($data->firstItem()+$key); ?></td>
                            <td>
                            <a href="<?php echo e(route('view', ['partId' => $item->part, 'novelId' => $item->judul])); ?>" class="btn btn-primary">Select</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-center">
                <?php echo $data->links(); ?>

                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\minenovel\resources\views/input-chapter.blade.php ENDPATH**/ ?>