

<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row border-0">
    <div class="col">
        <div class="card border-0">
            <ul class="pagination">
                <div class="col text-center-left">
                    <li class="page-item">
                        <a class="page-link border-0"  href="<?php echo e(route('view', ['partId' => $back, 'novelId' => $data->judul])); ?>">Previous</a>
                    </li>
                </div>
                <div class="col text-center">
                    <li class="page-item ">
                        <a class="page-link border-0" href="<?php echo e(route('create', ['novelId' => $data->judul])); ?>">Index</a>
                    </li>
                </div>
                <div class="col">
                    <li class="page-item text-right">
                        <a class="page-link border-0" href="<?php echo e(route('view', ['partId' => $next, 'novelId' => $data->judul])); ?>">Previous</a>
                    </li>
                </div>
            </ul>
        </div>
     </div>
</div>

<div class="row justify-content-md-center">
    <div class="col border-0">
        <?php echo nl2br(e($data->chapter)); ?>

    </div>
</div>
<br>

<div class="row border-0">
    <div class="col">
        <div class="card border-0">
            <ul class="pagination">
                <div class="col text-center-left">
                    <li class="page-item">
                        <a class="page-link border-0"  href="<?php echo e(route('view', ['partId' => $back, 'novelId' => $data->judul])); ?>">Previous</a>
                    </li>
                </div>
                <div class="col text-center">
                    <li class="page-item ">
                        <a class="page-link border-0" href="<?php echo e(route('create', ['novelId' => $data->judul])); ?>">Index</a>
                    </li>
                </div>
                <div class="col">
                    <li class="page-item text-right">
                        <a class="page-link border-0" href="<?php echo e(route('view', ['partId' => $next, 'novelId' => $data->judul])); ?>">Previous</a>
                    </li>
                </div>
            </ul>
        </div>
     </div>
</div>
</div>




<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\minenovel\resources\views/chapter-view.blade.php ENDPATH**/ ?>