

<?php $__env->startSection('content'); ?>
        <h1><?php echo e($title); ?></h1>
        <p>This is the about page for an example Laravel web application.</p>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\minenovel\resources\views/about.blade.php ENDPATH**/ ?>