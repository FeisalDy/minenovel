

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-3">
                <div class="card border-0">
                    <img src="<?php echo e(asset('file_upload')); ?>/<?php echo e($data->file); ?>" class="img-fluid">
                </div>
            </div>
            <div class="col-9"> 
                <div class="card border-0">
                        <h3><?php echo e($data->title); ?></h3>
                        <?php echo nl2br(e($data->keterangan)); ?>

                </div>
            </div>
        </div>
        <br>
        <div>
            <?php $__currentLoopData = $data2->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-4">
                            <a href="<?php echo e(route('view', ['partId' => $item->part, 'novelId' => $item->judul])); ?>">Chapter <?php echo e($item->part); ?></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\minenovel\resources\views/novelinfo.blade.php ENDPATH**/ ?>